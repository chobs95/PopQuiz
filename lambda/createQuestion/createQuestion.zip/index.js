exports.handler = async (event) => {
    const message = 'Hello from Lambda!';
    return {
        statusCode: 200,
        body: JSON.stringify({ message }),
    };
};